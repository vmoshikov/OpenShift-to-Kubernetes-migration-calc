package main

import (
	"flag"
	"fmt"
	"os"
)

func main() {
	source := flag.String("source", "mock", "источник данных: mock | kubectl | oc")
	namespace := flag.String("namespace", "all", "namespace для kubectl/oc источника ('all' — все неймспейсы)")
	envFilter := flag.String("env", "all", "какие контуры считать: all | dev | ift | psi | prom")
	review := flag.Bool("review", false, "запросить ревью плана у OpenAI-совместимой модели")
	flag.Parse()

	deployments, err := loadDeployments(*source, *namespace)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Ошибка получения данных стенда:", err)
		os.Exit(1)
	}

	fmt.Printf("Источник: %s | Namespace: %s\n", *source, *namespace)
	fmt.Printf("Деплойментов: %d\n", len(deployments))
	totalPods := 0
	for _, d := range deployments {
		totalPods += d.Replicas
	}
	fmt.Printf("Подов (PROM-baseline из исходного стенда): %d\n\n", totalPods)

	flavors := DefaultFlavors()
	var results []EnvSizingResult
	for _, env := range DefaultProfiles() {
		if *envFilter != "all" && *envFilter != env.Key {
			continue
		}
		res := CalculateEnvSizing(deployments, env, flavors)
		results = append(results, res)
		printEnvReport(res)
	}

	printTotalCost(results)

	if *review {
		cfg := LoadReviewConfigFromEnv()
		fmt.Println("\n=== Ревью плана моделью (" + cfg.Model + ") ===")
		text, err := ReviewSizingPlan(cfg, results)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Ревью недоступно:", err)
		} else {
			fmt.Println(text)
		}
	}
}

func loadDeployments(source, namespace string) ([]DeploymentSpec, error) {
	switch source {
	case "mock":
		return MockDeployments(), nil
	case "kubectl":
		return FetchDeploymentsFromCluster("kubectl", namespace)
	case "oc":
		return FetchDeploymentsFromCluster("oc", namespace)
	default:
		return nil, fmt.Errorf("неизвестный источник %q (ожидается mock | kubectl | oc)", source)
	}
}

func printEnvReport(r EnvSizingResult) {
	fmt.Printf("--- Контур: %s ---\n", r.Env.Label)
	fmt.Printf("  Подов:                 %d\n", r.TotalPods)
	fmt.Printf("  Спрос (без headroom):  %d m CPU, %d MiB RAM\n", r.RawCPUMilli, r.RawMemMiB)
	fmt.Printf("  Спрос (+%.0f%% headroom): %d m CPU, %d MiB RAM\n", r.Env.HeadroomPercent*100, r.DemandCPUMilli, r.DemandMemMiB)
	fmt.Printf("  Рекомендация:          %d x %s (overcommit CPU x%.1f)\n", r.NodeCount, r.BestFlavor.Name, r.Env.CPUOvercommit)
	fmt.Printf("  Утилизация узлов:      CPU %.1f%%, RAM %.1f%%\n", r.CPUUtilization, r.MemUtilization)
	fmt.Printf("  Стоимость:             %.1f RUB/час\n\n", r.EstCostPerHourRUB)
}

func printTotalCost(results []EnvSizingResult) {
	var total float64
	for _, r := range results {
		total += r.EstCostPerHourRUB
	}
	fmt.Printf("=== Итого по всем выбранным контурам: %.1f RUB/час (~%.0f RUB/мес) ===\n", total, total*24*30)
}
