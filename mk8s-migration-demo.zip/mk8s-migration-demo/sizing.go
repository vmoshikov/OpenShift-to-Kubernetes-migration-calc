package main

import "math"

// CalculateEnvSizing считает спрос на ресурсы для одного контура (DEV/IFT/ПСИ/ПРОМ)
// на основе исходных OpenShift-деплойментов и подбирает наиболее эффективный
// (по количеству узлов, затем по стоимости) флейвор из каталога.
func CalculateEnvSizing(deployments []DeploymentSpec, env EnvProfile, flavors []NodeFlavor) EnvSizingResult {
	var rawCPU, rawMem int64
	var totalPods int

	for _, d := range deployments {
		effectiveReplicas := int(math.Round(float64(d.Replicas) * env.ReplicaFactor))
		if effectiveReplicas < env.MinReplicas {
			effectiveReplicas = env.MinReplicas
		}
		per := d.PerPodRequests()
		rawCPU += per.CPUMilli * int64(effectiveReplicas)
		rawMem += per.MemMiB * int64(effectiveReplicas)
		totalPods += effectiveReplicas
	}

	// Запас на HA/failover/рост поверх суммарного спроса.
	demandCPU := int64(math.Ceil(float64(rawCPU) * (1 + env.HeadroomPercent)))
	demandMem := int64(math.Ceil(float64(rawMem) * (1 + env.HeadroomPercent)))

	best := pickBestFlavor(demandCPU, demandMem, env, flavors)

	return EnvSizingResult{
		Env:               env,
		TotalPods:         totalPods,
		RawCPUMilli:       rawCPU,
		RawMemMiB:         rawMem,
		DemandCPUMilli:    demandCPU,
		DemandMemMiB:      demandMem,
		BestFlavor:        best.flavor,
		NodeCount:         best.nodeCount,
		CPUUtilization:    best.cpuUtil,
		MemUtilization:    best.memUtil,
		EstCostPerHourRUB: best.flavor.PricePerHourRUB * float64(best.nodeCount),
	}
}

type flavorFit struct {
	flavor    NodeFlavor
	nodeCount int
	cpuUtil   float64
	memUtil   float64
}

// pickBestFlavor перебирает каталог флейворов и для каждого считает,
// сколько узлов нужно под спрос с учётом системного резерва и CPU overcommit,
// затем выбирает вариант с минимальной итоговой стоимостью в час
// (при равенстве — с меньшим числом узлов, что обычно проще в эксплуатации).
func pickBestFlavor(demandCPU, demandMem int64, env EnvProfile, flavors []NodeFlavor) flavorFit {
	var best flavorFit
	bestCost := math.MaxFloat64

	for _, f := range flavors {
		usableCPU := int64(float64(f.CPUMilli-env.SystemReserveCPU) * env.CPUOvercommit)
		usableMem := f.MemMiB - env.SystemReserveMem
		if usableCPU <= 0 || usableMem <= 0 {
			continue // флейвор слишком мал даже под системный резерв — пропускаем
		}

		nodesByCPU := int(math.Ceil(float64(demandCPU) / float64(usableCPU)))
		nodesByMem := int(math.Ceil(float64(demandMem) / float64(usableMem)))
		nodeCount := nodesByCPU
		if nodesByMem > nodeCount {
			nodeCount = nodesByMem
		}
		if nodeCount < 1 {
			nodeCount = 1
		}

		cost := f.PricePerHourRUB * float64(nodeCount)
		if cost < bestCost {
			bestCost = cost
			best = flavorFit{
				flavor:    f,
				nodeCount: nodeCount,
				cpuUtil:   100 * float64(demandCPU) / float64(usableCPU*int64(nodeCount)),
				memUtil:   100 * float64(demandMem) / float64(usableMem*int64(nodeCount)),
			}
		}
	}
	return best
}
